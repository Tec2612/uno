# UNO Mercy — Android Studio Card Game

A complete, production-ready Android Studio project written in **Kotlin** with **Jetpack Compose** and **Material 3**. UNO Mercy is an original color-matching multiplayer card game with offline-first gameplay, 2–10 players (Human + AI Bots with 3 difficulty levels), configurable "No Mercy" house rules (Draw Stacking, Skip Stacking, 7-Swap, 0-Rotate, Elimination Mode), and Firebase Real-Time Multiplayer integration.

## 🚀 Quick Start in Android Studio

1. **Prerequisites**:
   - Android Studio (Hedgehog 2023.1+ or Ladybug 2024.2+)
   - JDK 17 or higher
   - Android SDK 34+ (Android 8.0 Oreo, API 26 minimum target)

2. **Open the Project**:
   - Clone or extract this project folder.
   - Launch Android Studio and click **Open**.
   - Select the root directory and allow Gradle to sync.

3. **Firebase Setup (Optional for Multiplayer)**:
   - Go to [Firebase Console](https://console.firebase.google.com/).
   - Create a project and add an Android app with package: `com.unomercy.game`.
   - Download `google-services.json` and place it in the `app/` directory.
   - Enable **Anonymous Authentication** and **Cloud Firestore** in test mode.

4. **Run the Game**:
   - Select an emulator or physical device running Android 8.0+.
   - Click **Run 'app'** (Shift + F10). Enjoy!
