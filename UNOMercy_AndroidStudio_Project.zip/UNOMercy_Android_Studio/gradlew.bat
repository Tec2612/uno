@rem Gradle wrapper batch script placeholder
@gradle %*
