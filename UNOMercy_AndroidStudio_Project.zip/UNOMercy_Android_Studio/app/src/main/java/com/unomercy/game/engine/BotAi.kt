package com.unomercy.game.engine

import com.unomercy.game.model.*

object BotAi {
    data class BotMove(
        val card: Card?,
        val chosenColor: CardColor,
        val targetSwapPlayerId: String? = null
    )

    fun calculateMove(
        bot: Player,
        topCard: Card,
        activeColor: CardColor,
        accumulatedDraws: Int,
        ruleSet: RuleSet,
        allPlayers: List<Player>,
        direction: Int
    ): BotMove {
        val playable = bot.hand.filter {
            GameEngine.isPlayable(it, topCard, activeColor, accumulatedDraws, ruleSet)
        }

        if (playable.isEmpty()) {
            return BotMove(null, activeColor)
        }

        val difficulty = bot.botDifficulty ?: BotDifficulty.MEDIUM
        val activePlayers = allPlayers.filter { !it.isEliminated }
        val currentIdx = activePlayers.indexOfFirst { it.id == bot.id }
        val nextPlayer = if (direction == 1) {
            activePlayers[(currentIdx + 1) % activePlayers.size]
        } else {
            activePlayers[(currentIdx - 1 + activePlayers.size) % activePlayers.size]
        }

        // Color counting helper
        fun bestColor(): CardColor {
            val colorCounts = mutableMapOf(
                CardColor.RED to 0, CardColor.BLUE to 0, CardColor.GREEN to 0, CardColor.YELLOW to 0
            )
            bot.hand.forEach { if (it.color != CardColor.WILD) colorCounts[it.color] = (colorCounts[it.color] ?: 0) + 1 }
            return colorCounts.maxByOrNull { it.value }?.key ?: CardColor.RED
        }

        return when (difficulty) {
            BotDifficulty.EASY -> {
                val card = playable.random()
                val color = if (card.color == CardColor.WILD) {
                    listOf(CardColor.RED, CardColor.BLUE, CardColor.GREEN, CardColor.YELLOW).random()
                } else card.color
                val targetId = if (card.value == 7 && ruleSet.sevenSwap) {
                    activePlayers.filter { it.id != bot.id }.randomOrNull()?.id
                } else null
                BotMove(card, color, targetId)
            }
            BotDifficulty.MEDIUM -> {
                val nonWild = playable.filter { it.color != CardColor.WILD }
                val card = if (nonWild.isNotEmpty()) nonWild.random() else playable.first()
                val color = if (card.color == CardColor.WILD) bestColor() else card.color
                val targetId = if (card.value == 7 && ruleSet.sevenSwap) {
                    activePlayers.filter { it.id != bot.id && it.hand.size < bot.hand.size }
                        .minByOrNull { it.hand.size }?.id
                } else null
                BotMove(card, color, targetId)
            }
            BotDifficulty.HARD -> {
                // Hard mode:
                val card = if (accumulatedDraws > 0) {
                    playable.firstOrNull { it.type == CardType.WILD_DRAW_FOUR }
                        ?: playable.firstOrNull { it.type == CardType.DRAW_TWO }
                        ?: playable.first()
                } else if (nextPlayer.hand.size <= 2) {
                    // Attack next player with draw/skip
                    playable.firstOrNull { it.type == CardType.WILD_DRAW_FOUR }
                        ?: playable.firstOrNull { it.type == CardType.DRAW_TWO }
                        ?: playable.firstOrNull { it.type == CardType.SKIP }
                        ?: playable.firstOrNull { it.type == CardType.REVERSE }
                        ?: playable.first()
                } else {
                    // Dump high point cards first
                    playable.sortedByDescending { it.scoreValue }.first()
                }
                val color = if (card.color == CardColor.WILD) bestColor() else card.color
                val targetId = if (card.value == 7 && ruleSet.sevenSwap) {
                    activePlayers.filter { it.id != bot.id }.minByOrNull { it.hand.size }?.id
                } else null
                BotMove(card, color, targetId)
            }
        }
    }
}
