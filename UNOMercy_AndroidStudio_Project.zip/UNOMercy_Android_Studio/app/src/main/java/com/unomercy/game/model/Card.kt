package com.unomercy.game.model

import java.util.UUID

enum class CardColor {
    RED, BLUE, GREEN, YELLOW, WILD
}

enum class CardType {
    NUMBER, SKIP, REVERSE, DRAW_TWO, WILD_COLOR, WILD_DRAW_FOUR
}

data class Card(
    val id: String = UUID.randomUUID().toString(),
    val color: CardColor,
    val type: CardType,
    val value: Int? = null,
    val scoreValue: Int = when (type) {
        CardType.NUMBER -> value ?: 0
        CardType.SKIP, CardType.REVERSE, CardType.DRAW_TWO -> 20
        CardType.WILD_COLOR, CardType.WILD_DRAW_FOUR -> 50
    }
) {
    val displayLabel: String
        get() = when (type) {
            CardType.NUMBER -> value?.toString() ?: ""
            CardType.SKIP -> "⊘"
            CardType.REVERSE -> "⇄"
            CardType.DRAW_TWO -> "+2"
            CardType.WILD_COLOR -> "★"
            CardType.WILD_DRAW_FOUR -> "+4"
        }
}
