package com.unomercy.game.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unomercy.game.engine.GameEngine
import com.unomercy.game.model.Card
import com.unomercy.game.model.CardColor
import com.unomercy.game.ui.components.PlayingCardView
import com.unomercy.game.viewmodel.GameViewModel

@Composable
fun GameTableScreen(
    viewModel: GameViewModel,
    onFinishGame: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val humanPlayer = uiState.players.firstOrNull { !it.isBot }
    val isHumanTurn = uiState.players.getOrNull(uiState.currentPlayerIndex)?.isBot == false

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF1E3A2F), Color(0xFF0F1E18), Color(0xFF070B09))
                )
            )
    ) {
        // Table center discard and draw deck
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Action log / notice banner
            Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Text(
                    text = uiState.actionNotice,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Draw Deck
                Box(
                    modifier = Modifier
                        .size(72.dp, 104.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF27272A))
                        .border(2.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .clickable(enabled = isHumanTurn) {
                            viewModel.drawCardsForCurrentPlayer()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Add, contentDescription = "Draw", tint = Color.White)
                        Text("DRAW", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                // Discard Pile
                val topCard = uiState.discardPile.lastOrNull()
                if (topCard != null) {
                    PlayingCardView(
                        card = topCard,
                        width = 76.dp,
                        height = 110.dp,
                        isPlayable = false
                    )
                }

                // Active Color Indicator
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            when (uiState.activeColor) {
                                CardColor.RED -> Color(0xFFDC2626)
                                CardColor.BLUE -> Color(0xFF2563EB)
                                CardColor.GREEN -> Color(0xFF16A34A)
                                CardColor.YELLOW -> Color(0xFFEAB308)
                                else -> Color.White
                            }
                        )
                        .border(2.dp, Color.White, CircleShape)
                )
            }

            // Draw stack indicator badge
            if (uiState.accumulatedDraws > 0) {
                Surface(
                    color = Color(0xFFDC2626),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Text(
                        text = "DRAW PENALTY: +${uiState.accumulatedDraws} CARDS",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Circular opponents list at top/sides
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            uiState.players.filter { it.isBot }.forEachIndexed { index, bot ->
                val isTurn = uiState.players.indexOf(bot) == uiState.currentPlayerIndex
                Surface(
                    color = if (isTurn) Color(0xFFEAB308).copy(alpha = 0.2f) else Color.Black.copy(alpha = 0.4f),
                    border = if (isTurn) androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFEAB308)) else null,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(bot.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("${bot.hand.size} cards", color = Color.LightGray, fontSize = 11.sp)
                    }
                }
            }
        }

        // Bottom Human Player Hand Tray
        if (humanPlayer != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy((-18).dp)
                ) {
                    items(humanPlayer.hand, key = { it.id }) { card ->
                        val top = uiState.discardPile.lastOrNull()
                        val playable = top != null && isHumanTurn && GameEngine.isPlayable(
                            card, top, uiState.activeColor, uiState.accumulatedDraws, uiState.ruleSet
                        )

                        PlayingCardView(
                            card = card,
                            width = 68.dp,
                            height = 100.dp,
                            isPlayable = playable,
                            onClick = {
                                if (card.color == CardColor.WILD) {
                                    // Open color picker dialog
                                    viewModel.playCard(humanPlayer, card, CardColor.RED)
                                } else {
                                    viewModel.playCard(humanPlayer, card)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
