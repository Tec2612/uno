package com.unomercy.game.model

data class RuleSet(
    val stackDrawCards: Boolean = true,     // +2 on +2, +4 on +2 or +4
    val skipStacking: Boolean = true,       // Skip can be passed or stacked
    val sevenSwap: Boolean = true,          // Playing a 7 lets you swap hands
    val zeroRotate: Boolean = true,         // Playing a 0 rotates all hands
    val eliminationMode: Boolean = false,   // Hand >= eliminationLimit knocks you out
    val eliminationLimit: Int = 25,         // Max cards before elimination
    val drawUntilMatch: Boolean = false     // Keep drawing until legal card
)
