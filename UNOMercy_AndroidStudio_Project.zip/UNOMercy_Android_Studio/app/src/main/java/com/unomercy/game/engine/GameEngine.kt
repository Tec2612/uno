package com.unomercy.game.engine

import com.unomercy.game.model.*
import java.util.UUID

class GameEngine(
    val ruleSet: RuleSet = RuleSet()
) {
    companion object {
        fun createDeck(): List<Card> {
            val cards = mutableListOf<Card>()
            val colors = listOf(CardColor.RED, CardColor.BLUE, CardColor.GREEN, CardColor.YELLOW)

            colors.forEach { color ->
                // One '0' card
                cards.add(Card(id = UUID.randomUUID().toString(), color = color, type = CardType.NUMBER, value = 0))

                // Two 1-9 cards
                for (v in 1..9) {
                    repeat(2) {
                        cards.add(Card(id = UUID.randomUUID().toString(), color = color, type = CardType.NUMBER, value = v))
                    }
                }

                // Action cards
                repeat(2) {
                    cards.add(Card(id = UUID.randomUUID().toString(), color = color, type = CardType.SKIP))
                    cards.add(Card(id = UUID.randomUUID().toString(), color = color, type = CardType.REVERSE))
                    cards.add(Card(id = UUID.randomUUID().toString(), color = color, type = CardType.DRAW_TWO))
                }
            }

            // Wild cards
            repeat(4) {
                cards.add(Card(id = UUID.randomUUID().toString(), color = CardColor.WILD, type = CardType.WILD_COLOR))
                cards.add(Card(id = UUID.randomUUID().toString(), color = CardColor.WILD, type = CardType.WILD_DRAW_FOUR))
            }

            return cards.shuffled()
        }

        fun isPlayable(
            card: Card,
            topCard: Card,
            activeColor: CardColor,
            accumulatedDraws: Int,
            ruleSet: RuleSet
        ): Boolean {
            if (accumulatedDraws > 0) {
                if (!ruleSet.stackDrawCards) return false
                if (card.type == CardType.DRAW_TWO && topCard.type == CardType.DRAW_TWO) return true
                if (card.type == CardType.WILD_DRAW_FOUR) return true
                return false
            }

            if (card.color == CardColor.WILD) return true
            if (card.color == activeColor) return true
            if (card.type == CardType.NUMBER && topCard.type == CardType.NUMBER) {
                return card.value == topCard.value
            }
            if (card.type != CardType.NUMBER && card.type == topCard.type) return true
            return false
        }
    }
}
