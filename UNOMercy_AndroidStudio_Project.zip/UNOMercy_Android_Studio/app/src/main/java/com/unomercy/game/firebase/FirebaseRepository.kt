package com.unomercy.game.firebase

import com.unomercy.game.model.Card
import com.unomercy.game.model.HouseRulesData
import com.unomercy.game.model.RuleSet
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class RoomState(
    val roomCode: String = "",
    val hostId: String = "",
    val playerIds: List<String> = emptyList(),
    val playerNames: Map<String, String> = emptyMap(),
    val status: String = "LOBBY", // LOBBY, IN_GAME, FINISHED
    val activeColor: String = "RED",
    val currentTurnPlayerId: String = "",
    val topCardJson: String = "",
    val accumulatedDraws: Int = 0
)

class FirebaseRepository {
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    suspend fun signInAnonymously(): String {
        val user = auth.currentUser ?: auth.signInAnonymously().await().user
        return user?.uid ?: throw IllegalStateException("Firebase auth failed")
    }

    suspend fun createRoom(roomCode: String, hostName: String, ruleSet: RuleSet): String {
        val uid = signInAnonymously()
        val roomData = hashMapOf(
            "roomCode" to roomCode,
            "hostId" to uid,
            "playerIds" to listOf(uid),
            "playerNames" to mapOf(uid to hostName),
            "status" to "LOBBY",
            "accumulatedDraws" to 0
        )
        firestore.collection("rooms").document(roomCode).set(roomData).await()
        return roomCode
    }

    suspend fun joinRoom(roomCode: String, playerName: String) {
        val uid = signInAnonymously()
        val roomRef = firestore.collection("rooms").document(roomCode)
        firestore.runTransaction { tx ->
            val snapshot = tx.get(roomRef)
            val currentPlayers = snapshot.get("playerIds") as? List<String> ?: emptyList()
            val currentNames = (snapshot.get("playerNames") as? Map<String, String>)?.toMutableMap() ?: mutableMapOf()

            if (!currentPlayers.contains(uid)) {
                val updatedPlayers = currentPlayers + uid
                currentNames[uid] = playerName
                tx.update(roomRef, "playerIds", updatedPlayers)
                tx.update(roomRef, "playerNames", currentNames)
            }
        }.await()
    }

    fun observeRoom(roomCode: String): Flow<RoomState?> = callbackFlow {
        val listener: ListenerRegistration = firestore.collection("rooms").document(roomCode)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val room = RoomState(
                        roomCode = snapshot.getString("roomCode") ?: "",
                        hostId = snapshot.getString("hostId") ?: "",
                        playerIds = snapshot.get("playerIds") as? List<String> ?: emptyList(),
                        playerNames = snapshot.get("playerNames") as? Map<String, String> ?: emptyMap(),
                        status = snapshot.getString("status") ?: "LOBBY",
                        activeColor = snapshot.getString("activeColor") ?: "RED",
                        currentTurnPlayerId = snapshot.getString("currentTurnPlayerId") ?: "",
                        accumulatedDraws = snapshot.getLong("accumulatedDraws")?.toInt() ?: 0
                    )
                    trySend(room)
                } else {
                    trySend(null)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun handleHostMigration(roomCode: String, newHostId: String) {
        firestore.collection("rooms").document(roomCode)
            .update("hostId", newHostId).await()
    }
}
