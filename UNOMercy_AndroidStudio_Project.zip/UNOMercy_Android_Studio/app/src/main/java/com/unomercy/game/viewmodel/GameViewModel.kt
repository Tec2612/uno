package com.unomercy.game.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.unomercy.game.engine.BotAi
import com.unomercy.game.engine.GameEngine
import com.unomercy.game.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GameUiState(
    val players: List<Player> = emptyList(),
    val currentPlayerIndex: Int = 0,
    val direction: Int = 1, // 1 = clockwise, -1 = counter-clockwise
    val drawDeck: List<Card> = emptyList(),
    val discardPile: List<Card> = emptyList(),
    val activeColor: CardColor = CardColor.RED,
    val accumulatedDraws: Int = 0,
    val isColorPickOpen: Boolean = false,
    val isSwapPickOpen: Boolean = false,
    val pendingPlayedCard: Card? = null,
    val winner: Player? = null,
    val actionNotice: String = "Game Started",
    val ruleSet: RuleSet = RuleSet()
)

class GameViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    fun startNewGame(playerCount: Int, ruleSet: RuleSet, botDifficulty: BotDifficulty) {
        val fullDeck = GameEngine.createDeck().toMutableList()
        val players = mutableListOf<Player>()

        // Human player (Player 1)
        players.add(
            Player(
                name = "You",
                isBot = false,
                avatarColorHex = "#3B82F6",
                hand = fullDeck.take(7).also { fullDeck.removeAll(it) }
            )
        )

        // Bots
        val botNames = listOf("Alex", "Nova", "Cyber", "Echo", "Blaze", "Viper", "Titan", "Luna", "Frost")
        for (i in 1 until playerCount) {
            players.add(
                Player(
                    name = botNames.getOrElse(i - 1) { "Bot $i" },
                    isBot = true,
                    botDifficulty = botDifficulty,
                    avatarColorHex = "#10B981",
                    hand = fullDeck.take(7).also { fullDeck.removeAll(it) }
                )
            )
        }

        // Top starter card (must not be wild)
        var starterCard = fullDeck.removeAt(0)
        while (starterCard.color == CardColor.WILD) {
            fullDeck.add(starterCard)
            fullDeck.shuffle()
            starterCard = fullDeck.removeAt(0)
        }

        _uiState.update {
            GameUiState(
                players = players,
                currentPlayerIndex = 0,
                direction = 1,
                drawDeck = fullDeck,
                discardPile = listOf(starterCard),
                activeColor = starterCard.color,
                accumulatedDraws = 0,
                ruleSet = ruleSet,
                actionNotice = "First card: ${starterCard.color} ${starterCard.displayLabel}"
            )
        }
    }

    fun playCard(player: Player, card: Card, chosenWildColor: CardColor? = null, targetSwapPlayerId: String? = null) {
        val state = _uiState.value
        val top = state.discardPile.lastOrNull() ?: return
        if (!GameEngine.isPlayable(card, top, state.activeColor, state.accumulatedDraws, state.ruleSet)) return

        val newHand = player.hand.filter { it.id != card.id }
        val updatedPlayers = state.players.map { if (it.id == player.id) it.copy(hand = newHand) else it }.toMutableList()

        var newAccumulatedDraws = state.accumulatedDraws
        var newDirection = state.direction
        var newActiveColor = if (card.color == CardColor.WILD) (chosenWildColor ?: CardColor.RED) else card.color
        var notice = "${player.name} played ${card.displayLabel}"

        // Handle Card Types
        when (card.type) {
            CardType.DRAW_TWO -> {
                newAccumulatedDraws = if (state.ruleSet.stackDrawCards) newAccumulatedDraws + 2 else 2
            }
            CardType.WILD_DRAW_FOUR -> {
                newAccumulatedDraws = if (state.ruleSet.stackDrawCards) newAccumulatedDraws + 4 else 4
            }
            CardType.REVERSE -> {
                newDirection = -newDirection
                notice += " (Reversed!)"
            }
            CardType.SKIP -> {
                notice += " (Skip!)"
            }
            CardType.NUMBER -> {
                if (card.value == 7 && state.ruleSet.sevenSwap && targetSwapPlayerId != null) {
                    val pIdx = updatedPlayers.indexOfFirst { it.id == player.id }
                    val tIdx = updatedPlayers.indexOfFirst { it.id == targetSwapPlayerId }
                    if (pIdx != -1 && tIdx != -1) {
                        val tempHand = updatedPlayers[pIdx].hand
                        updatedPlayers[pIdx] = updatedPlayers[pIdx].copy(hand = updatedPlayers[tIdx].hand)
                        updatedPlayers[tIdx] = updatedPlayers[tIdx].copy(hand = tempHand)
                        notice += " swapped hands with ${updatedPlayers[tIdx].name}!"
                    }
                } else if (card.value == 0 && state.ruleSet.zeroRotate) {
                    // Rotate hands in current turn direction
                    val hands = updatedPlayers.map { it.hand }
                    val rotatedHands = if (newDirection == 1) {
                        listOf(hands.last()) + hands.dropLast(1)
                    } else {
                        hands.drop(1) + listOf(hands.first())
                    }
                    updatedPlayers.indices.forEach { i ->
                        updatedPlayers[i] = updatedPlayers[i].copy(hand = rotatedHands[i])
                    }
                    notice += " rotated all player hands!"
                }
            }
            else -> {}
        }

        // Check Win
        if (newHand.isEmpty()) {
            _uiState.update {
                it.copy(
                    players = updatedPlayers,
                    discardPile = it.discardPile + card,
                    winner = player,
                    actionNotice = "${player.name} won the match!"
                )
            }
            return
        }

        // Check Elimination mode
        if (state.ruleSet.eliminationMode) {
            updatedPlayers.indices.forEach { i ->
                if (updatedPlayers[i].hand.size >= state.ruleSet.eliminationLimit && !updatedPlayers[i].isEliminated) {
                    updatedPlayers[i] = updatedPlayers[i].copy(isEliminated = true)
                    notice += " ${updatedPlayers[i].name} was ELIMINATED!"
                }
            }
        }

        // Advance turn
        val activeIndices = updatedPlayers.indices.filter { !updatedPlayers[it].isEliminated }
        var nextIdx = state.currentPlayerIndex
        val step = if (card.type == CardType.SKIP) newDirection * 2 else newDirection
        var nextStepCount = if (step > 0) step else (step % activeIndices.size + activeIndices.size)
        nextIdx = (nextIdx + nextStepCount) % updatedPlayers.size

        while (updatedPlayers[nextIdx].isEliminated) {
            nextIdx = (nextIdx + newDirection + updatedPlayers.size) % updatedPlayers.size
        }

        _uiState.update {
            it.copy(
                players = updatedPlayers,
                discardPile = it.discardPile + card,
                activeColor = newActiveColor,
                accumulatedDraws = newAccumulatedDraws,
                direction = newDirection,
                currentPlayerIndex = nextIdx,
                actionNotice = notice
            )
        }

        triggerBotIfNeeded()
    }

    fun drawCardsForCurrentPlayer() {
        val state = _uiState.value
        val player = state.players[state.currentPlayerIndex]
        val drawCount = if (state.accumulatedDraws > 0) state.accumulatedDraws else 1

        val currentDeck = state.drawDeck.toMutableList()
        val drawn = mutableListOf<Card>()

        repeat(drawCount) {
            if (currentDeck.isEmpty()) {
                // Reshuffle discard
                val newCards = state.discardPile.dropLast(1).shuffled()
                currentDeck.addAll(newCards)
            }
            if (currentDeck.isNotEmpty()) {
                drawn.add(currentDeck.removeAt(0))
            }
        }

        val updatedPlayers = state.players.map {
            if (it.id == player.id) it.copy(hand = it.hand + drawn) else it
        }

        val nextIdx = (state.currentPlayerIndex + state.direction + updatedPlayers.size) % updatedPlayers.size

        _uiState.update {
            it.copy(
                players = updatedPlayers,
                drawDeck = currentDeck,
                accumulatedDraws = 0,
                currentPlayerIndex = nextIdx,
                actionNotice = "${player.name} drew $drawCount cards"
            )
        }

        triggerBotIfNeeded()
    }

    private fun triggerBotIfNeeded() {
        viewModelScope.launch {
            delay(1200)
            val state = _uiState.value
            if (state.winner != null) return@launch
            val current = state.players[state.currentPlayerIndex]
            if (current.isBot && !current.isEliminated) {
                val botMove = BotAi.calculateMove(
                    bot = current,
                    topCard = state.discardPile.last(),
                    activeColor = state.activeColor,
                    accumulatedDraws = state.accumulatedDraws,
                    ruleSet = state.ruleSet,
                    allPlayers = state.players,
                    direction = state.direction
                )

                if (botMove.card != null) {
                    playCard(current, botMove.card, botMove.chosenColor, botMove.targetSwapPlayerId)
                } else {
                    drawCardsForCurrentPlayer()
                }
            }
        }
    }
}
