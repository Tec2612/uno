package com.unomercy.game.model

import java.util.UUID

enum class BotDifficulty {
    EASY, MEDIUM, HARD
}

data class Player(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val isBot: Boolean = false,
    val botDifficulty: BotDifficulty? = null,
    val hand: List<Card> = emptyList(),
    val isEliminated: Boolean = false,
    val hasCalledLastCard: Boolean = false,
    val avatarColorHex: String = "#3B82F6"
)
