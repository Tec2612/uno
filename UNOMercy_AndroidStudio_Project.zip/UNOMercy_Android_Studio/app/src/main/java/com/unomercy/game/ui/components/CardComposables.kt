package com.unomercy.game.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unomercy.game.model.Card
import com.unomercy.game.model.CardColor
import com.unomercy.game.model.CardType

@Composable
fun PlayingCardView(
    card: Card,
    modifier: Modifier = Modifier,
    width: Dp = 64.dp,
    height: Dp = 96.dp,
    isPlayable: Boolean = true,
    isSelected: Boolean = false,
    onClick: () -> Unit = {}
) {
    val cardColor = when (card.color) {
        CardColor.RED -> Color(0xFFDC2626)
        CardColor.BLUE -> Color(0xFF2563EB)
        CardColor.GREEN -> Color(0xFF16A34A)
        CardColor.YELLOW -> Color(0xFFEAB308)
        CardColor.WILD -> Color(0xFF1E1B4B)
    }

    val backgroundBrush = if (card.color == CardColor.WILD) {
        Brush.sweepGradient(
            listOf(
                Color(0xFFDC2626),
                Color(0xFF2563EB),
                Color(0xFF16A34A),
                Color(0xFFEAB308),
                Color(0xFFDC2626)
            )
        )
    } else {
        Brush.verticalGradient(
            listOf(cardColor, cardColor.copy(alpha = 0.85f))
        )
    }

    val elevation = if (isSelected) 12.dp else if (isPlayable) 6.dp else 2.dp

    Box(
        modifier = modifier
            .width(width)
            .height(height)
            .shadow(elevation, RoundedCornerShape(10.dp))
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White)
            .border(2.dp, if (isSelected) Color.Yellow else Color.White, RoundedCornerShape(10.dp))
            .padding(3.dp)
            .clickable(enabled = isPlayable, onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(7.dp))
                .background(backgroundBrush),
            contentAlignment = Alignment.Center
        ) {
            // Center inner oval
            Box(
                modifier = Modifier
                    .fillMaxSize(0.85f)
                    .rotate(-20f)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = card.displayLabel,
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = (width.value * 0.42f).sp
                )
            }

            // Top-left label
            Text(
                text = card.displayLabel,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (width.value * 0.22f).sp,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(4.dp)
            )

            // Bottom-right label (inverted)
            Text(
                text = card.displayLabel,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (width.value * 0.22f).sp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .rotate(180f)
                    .padding(4.dp)
            )
        }
    }
}
