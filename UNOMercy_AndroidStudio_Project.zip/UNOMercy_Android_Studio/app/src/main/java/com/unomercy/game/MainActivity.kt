package com.unomercy.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.unomercy.game.model.BotDifficulty
import com.unomercy.game.model.RuleSet
import com.unomercy.game.ui.screens.GameTableScreen
import com.unomercy.game.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    val gameViewModel: GameViewModel = viewModel()

                    NavHost(navController = navController, startDestination = "game_table") {
                        composable("game_table") {
                            // Automatically start game with default 4 players and house rules
                            gameViewModel.startNewGame(
                                playerCount = 4,
                                ruleSet = RuleSet(),
                                botDifficulty = BotDifficulty.HARD
                            )
                            GameTableScreen(
                                viewModel = gameViewModel,
                                onFinishGame = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
